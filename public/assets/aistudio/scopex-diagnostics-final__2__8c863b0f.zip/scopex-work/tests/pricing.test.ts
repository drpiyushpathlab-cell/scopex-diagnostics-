import assert from "node:assert/strict";
import test from "node:test";
import type { BookingCatalogItem } from "@/lib/booking-types";
import { calculateRealPriceQuote } from "@/lib/pricing";

function item(overrides: Partial<BookingCatalogItem>): BookingCatalogItem {
  return {
    id: "cbc",
    kind: "test",
    slug: "cbc",
    name: "CBC",
    description: "Complete blood count",
    price: 300,
    mrp: 0,
    discount: 0,
    category: "Blood",
    href: "/tests/cbc-test",
    ...overrides
  };
}

test("uses ScopeX real prices as the pricing baseline", () => {
  const quote = calculateRealPriceQuote({
    items: [
      item({ id: "cbc", price: 300, mrp: 900 }),
      item({ id: "hba1c", price: 350, mrp: 800 })
    ],
    bundleRules: []
  });

  assert.equal(quote.realPriceSubtotal, 650);
  assert.equal(quote.subtotal, 650);
  assert.equal(quote.referenceTotal, 1700);
  assert.equal(quote.bundleSaving, 0);
  assert.equal(quote.collectionCharge, 0);
  assert.equal(quote.payableAmount, 650);
});

test("applies the best active bundle saving rule for multiple tests", () => {
  const quote = calculateRealPriceQuote({
    items: [
      item({ id: "cbc", price: 300 }),
      item({ id: "hba1c", price: 400 }),
      item({ id: "thyroid", price: 500 }),
      item({ id: "lipid", price: 600 })
    ],
    bundleRules: [
      { id: "two", title: "Two test saving", minEligibleTestCount: 2, discountType: "percent", value: 5 },
      { id: "four", title: "Four test saving", minEligibleTestCount: 4, discountType: "percent", value: 10 }
    ]
  });

  assert.equal(quote.realPriceSubtotal, 1800);
  assert.equal(quote.bundleSaving, 180);
  assert.equal(quote.collectionCharge, 0);
  assert.equal(quote.payableAmount, 1620);
  assert.equal(quote.appliedOffers[0]?.code, "FOUR");
});

test("adds configured home collection charge below the threshold", () => {
  const quote = calculateRealPriceQuote({
    items: [item({ price: 450 })],
    bundleRules: [],
    collectionPolicy: {
      enabled: true,
      threshold: 600,
      charge: 99,
      thresholdBasis: "after_bundle_saving"
    }
  });

  assert.equal(quote.realPriceSubtotal, 450);
  assert.equal(quote.collectionCharge, 99);
  assert.equal(quote.payableAmount, 549);
});

test("keeps home collection free when threshold is met", () => {
  const quote = calculateRealPriceQuote({
    items: [item({ price: 600 })],
    bundleRules: [],
    collectionPolicy: {
      enabled: true,
      threshold: 600,
      charge: 99,
      thresholdBasis: "after_bundle_saving"
    }
  });

  assert.equal(quote.collectionCharge, 0);
  assert.equal(quote.payableAmount, 600);
});


test("enforces both percentage and fixed rupee caps for each eligible test", () => {
  const quote = calculateRealPriceQuote({
    items: [
      item({ id: "cbc", price: 300, maxDiscountPercent: 10, maxDiscountAmount: 20 }),
      item({ id: "tsh", price: 1000, maxDiscountPercent: 10, maxDiscountAmount: 25 })
    ],
    bundleRules: [{ id: "all", title: "Bundle saving", minEligibleTestCount: 2, discountType: "percent", value: 20 }],
    collectionPolicy: { enabled: false, threshold: 0, charge: 0, thresholdBasis: "after_bundle_saving" }
  });

  assert.equal(quote.bundleSaving, 45);
  assert.deepEqual(quote.itemDiscounts.map((row) => row.appliedDiscount), [20, 25]);
  assert.equal(quote.payableAmount, 1255);
});

test("does not discount fixed packages unless an admin explicitly enables eligibility", () => {
  const fixedPackage = item({
    id: "full-body",
    kind: "package",
    name: "Full Body Checkup",
    price: 1200,
    mrp: 2000,
    bundleDiscountEligible: false
  });
  const quote = calculateRealPriceQuote({
    items: [fixedPackage, item({ id: "cbc", price: 300 }), item({ id: "tsh", price: 300 })],
    bundleRules: [{ id: "two", title: "Bundle saving", minEligibleTestCount: 2, discountType: "percent", value: 10 }],
    collectionPolicy: { enabled: false, threshold: 0, charge: 0, thresholdBasis: "after_bundle_saving" }
  });

  assert.equal(quote.realPriceSubtotal, 1800);
  assert.equal(quote.bundleSaving, 60);
  assert.equal(quote.payableAmount, 1740);
});

test("supports rule date windows and minimum eligible spend", () => {
  const quote = calculateRealPriceQuote({
    items: [item({ id: "cbc", price: 300 }), item({ id: "tsh", price: 300 })],
    now: new Date("2026-10-21T10:00:00.000Z"),
    bundleRules: [
      { id: "future", title: "Future", minEligibleTestCount: 2, discountType: "percent", value: 50, startsAt: "2026-10-22T00:00:00.000Z" },
      { id: "spend", title: "Spend tier", minEligibleTestCount: 2, minEligibleSpend: 700, discountType: "percent", value: 20 }
    ],
    collectionPolicy: { enabled: false, threshold: 0, charge: 0, thresholdBasis: "after_bundle_saving" }
  });

  assert.equal(quote.bundleSaving, 0);
  assert.equal(quote.payableAmount, 600);
});

test("reports savings amount and percentage from reference total", () => {
  const quote = calculateRealPriceQuote({
    items: [item({ id: "cbc", price: 300, mrp: 600 })],
    bundleRules: [],
    collectionPolicy: { enabled: false, threshold: 0, charge: 0, thresholdBasis: "after_bundle_saving" }
  });

  assert.equal(quote.savingsAmount, 300);
  assert.equal(quote.savingsPercent, 50);
});
