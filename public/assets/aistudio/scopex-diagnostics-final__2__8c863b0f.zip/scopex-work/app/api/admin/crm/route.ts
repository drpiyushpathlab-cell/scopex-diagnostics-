import { NextResponse } from "next/server";
import { z } from "zod";
import { verifyAppToken } from "@/backend/src/lib/jwt";
import { getSupabaseServiceClient } from "@/lib/supabase";

export const runtime = "nodejs";

const allowedRoles = new Set(["admin", "manager", "super_admin", "super-admin", "booking_manager", "customer_support"]);

function authorize(request: Request) {
  const header = request.headers.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7) : "";
  if (!token) return null;
  try {
    const payload = verifyAppToken(token);
    if (!allowedRoles.has(String(payload.role))) return null;
    return payload;
  } catch {
    return null;
  }
}

export async function GET(request: Request) {
  const actor = authorize(request);
  if (!actor) return NextResponse.json({ message: "Admin authorization required." }, { status: 401 });
  try {
    const supabase = getSupabaseServiceClient();
    const [leadsResult, settingsResult] = await Promise.all([
      supabase.from("leads").select("id, lead_type, name, phone, mobile, mobile_number, email, city, state, purpose, source, campaign, status, lead_status, priority, assigned_user_id, assigned_team, next_follow_up_at, last_contacted_at, created_at, metadata").order("created_at", { ascending: false }).limit(250),
      supabase.from("assignment_settings").select("id, workflow, assignment_mode, active, rules").order("workflow", { ascending: true })
    ]);
    if (leadsResult.error) throw new Error(leadsResult.error.message);
    if (settingsResult.error) throw new Error(settingsResult.error.message);
    return NextResponse.json({ leads: leadsResult.data ?? [], settings: settingsResult.data ?? [] });
  } catch (error) {
    return NextResponse.json({ message: error instanceof Error ? error.message : "Unable to load CRM." }, { status: 500 });
  }
}

const leadUpdateSchema = z.object({
  type: z.literal("lead"),
  id: z.string().uuid(),
  lead_status: z.enum(["New", "Contacted", "Qualified", "Follow-up", "Booking Pending", "Converted", "Not Interested", "Closed"]).optional(),
  priority: z.enum(["low", "normal", "high", "urgent"]).optional(),
  assigned_user_id: z.string().uuid().nullable().optional(),
  assigned_team: z.string().max(80).nullable().optional(),
  next_follow_up_at: z.string().datetime().nullable().optional(),
  note: z.string().max(2000).optional()
}).refine((value) => Object.keys(value).some((key) => !["type", "id"].includes(key)), { message: "Provide at least one field to update." });

const settingsUpdateSchema = z.object({
  type: z.literal("settings"),
  workflow: z.enum(["crm_leads", "phlebotomist_jobs"]),
  assignment_mode: z.enum(["manual", "automatic"]),
  active: z.boolean().optional()
});

export async function PATCH(request: Request) {
  const actor = authorize(request);
  if (!actor) return NextResponse.json({ message: "Admin authorization required." }, { status: 401 });
  try {
    const body: unknown = await request.json();
    const supabase = getSupabaseServiceClient();
    if (body && typeof body === "object" && "type" in body && body.type === "settings") {
      if (!(["super_admin", "super-admin", "admin"].includes(String(actor.role)))) {
        return NextResponse.json({ message: "Only an authorized admin can change assignment mode." }, { status: 403 });
      }
      const parsed = settingsUpdateSchema.parse(body);
      const { data, error } = await supabase.from("assignment_settings").update({
        assignment_mode: parsed.assignment_mode,
        ...(parsed.active !== undefined ? { active: parsed.active } : {}),
        updated_at: new Date().toISOString()
      }).eq("workflow", parsed.workflow).select("id, workflow, assignment_mode, active, rules").single();
      if (error || !data) throw new Error(error?.message || "Unable to update assignment mode.");
      return NextResponse.json({ success: true, setting: data });
    }

    const parsed = leadUpdateSchema.parse(body);
    const { data: oldLead, error: readError } = await supabase.from("leads").select("id, lead_status, priority, assigned_user_id, assigned_team, next_follow_up_at").eq("id", parsed.id).maybeSingle();
    if (readError || !oldLead) throw new Error(readError?.message || "Lead not found.");
    const update: Record<string, unknown> = { updated_at: new Date().toISOString() };
    for (const key of ["lead_status", "priority", "assigned_user_id", "assigned_team", "next_follow_up_at"] as const) {
      if (parsed[key] !== undefined) update[key] = parsed[key];
    }
    if (parsed.lead_status === "Contacted") update.last_contacted_at = new Date().toISOString();
    const { error: updateError } = await supabase.from("leads").update(update).eq("id", parsed.id);
    if (updateError) throw new Error(updateError.message);

    await supabase.from("lead_activity_log").insert({
      lead_id: parsed.id,
      activity_type: parsed.note ? "note" : parsed.assigned_user_id !== undefined ? "assigned" : parsed.lead_status ? "status_changed" : "follow_up_set",
      old_value: oldLead,
      new_value: update,
      note: parsed.note || null,
      actor_id: actor.userId
    });
    if (parsed.assigned_user_id !== undefined && parsed.assigned_user_id !== oldLead.assigned_user_id) {
      const { data: settings } = await supabase.from("assignment_settings").select("assignment_mode").eq("workflow", "crm_leads").maybeSingle();
      await supabase.from("lead_assignment_history").insert({
        lead_id: parsed.id,
        from_user_id: oldLead.assigned_user_id,
        to_user_id: parsed.assigned_user_id,
        team: parsed.assigned_team ?? oldLead.assigned_team,
        assignment_mode: settings?.assignment_mode === "automatic" ? "automatic" : "manual",
        assigned_by: actor.userId,
        rule_snapshot: { source: "admin_crm" }
      });
    }
    return NextResponse.json({ success: true });
  } catch (error) {
    if (error instanceof z.ZodError) return NextResponse.json({ message: "Invalid CRM update.", issues: error.issues }, { status: 400 });
    return NextResponse.json({ message: error instanceof Error ? error.message : "Unable to update CRM." }, { status: 500 });
  }
}
