import type { Metadata } from "next";
import { AdminSessionGuard } from "@/components/admin-session-guard";
import { AdminContentSearch } from "@/components/admin-content-search";

export const metadata: Metadata = {
  title: "SEO, AEO & GEO",
  description: "Manage SCOPEX Diagnostics search metadata and AI-discovery content."
};

export default function AdminContentSearchPage() {
  return <section className="section-wrap py-10"><AdminSessionGuard><AdminContentSearch /></AdminSessionGuard></section>;
}
