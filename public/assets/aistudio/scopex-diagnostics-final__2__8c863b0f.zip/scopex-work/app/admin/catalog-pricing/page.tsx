import type { Metadata } from "next";
import { AdminSessionGuard } from "@/components/admin-session-guard";
import { AdminCatalogPricing } from "@/components/admin-catalog-pricing";

export const metadata: Metadata = {
  title: "Catalog & Pricing",
  description: "Manage SCOPEX Diagnostics test prices, package rules and per-test discount caps."
};

export default function AdminCatalogPricingPage() {
  return <section className="section-wrap py-10"><AdminSessionGuard><AdminCatalogPricing /></AdminSessionGuard></section>;
}
