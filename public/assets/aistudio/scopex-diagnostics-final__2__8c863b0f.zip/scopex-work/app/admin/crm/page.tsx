import type { Metadata } from "next";
import { AdminSessionGuard } from "@/components/admin-session-guard";
import { AdminCrm } from "@/components/admin-crm";

export const metadata: Metadata = {
  title: "CRM & Lead Routing",
  description: "Manage SCOPEX Diagnostics leads, follow-ups and assignment workflows."
};

export default function AdminCrmPage() {
  return <section className="section-wrap py-10"><AdminSessionGuard><AdminCrm /></AdminSessionGuard></section>;
}
