"use client";

import { useCallback, useEffect, useState } from "react";
import { backendFetch } from "@/lib/backend-client";

type ContentRow = {
  id: string;
  name?: string;
  title?: string;
  slug?: string;
  seo_title?: string | null;
  seo_description?: string | null;
  canonical_url?: string | null;
  indexable?: boolean;
  geo_summary?: string | null;
  content_review_status?: string;
  status?: string;
};

export function AdminContentSearch() {
  const [rows, setRows] = useState<ContentRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");
  const [saving, setSaving] = useState("");

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const [testsRes, packagesRes, blogsRes] = await Promise.all([
        backendFetch("/admin/tests"), backendFetch("/admin/packages"), backendFetch("/admin/blog_posts")
      ]);
      const [testsJson, packagesJson, blogsJson] = await Promise.all([
        testsRes.json().catch(() => ({})), packagesRes.json().catch(() => ({})), blogsRes.json().catch(() => ({}))
      ]);
      const combine = (values: ContentRow[], type: string) => values.map((row) => ({ ...row, _type: type } as ContentRow));
      setRows([
        ...combine(testsRes.ok ? testsJson.data ?? [] : [], "Test"),
        ...combine(packagesRes.ok ? packagesJson.data ?? [] : [], "Package"),
        ...combine(blogsRes.ok ? blogsJson.data ?? [] : [], "Article")
      ]);
      if (![testsRes, packagesRes, blogsRes].some((res) => res.ok)) setMessage("Unable to load content. Check admin login and backend database configuration.");
      else setMessage("");
    } catch {
      setMessage("Backend is not reachable. Start the backend and sign in as an admin.");
    } finally { setLoading(false); }
  }, []);

  useEffect(() => { void load(); }, [load]);

  function patch(id: string, field: keyof ContentRow, value: unknown) {
    setRows((current) => current.map((row) => row.id === id ? { ...row, [field]: value } : row));
  }

  async function save(row: ContentRow) {
    const type = (row as ContentRow & { _type?: string })._type;
    const resource = type === "Test" ? "tests" : type === "Package" ? "packages" : "blog_posts";
    setSaving(row.id); setMessage("");
    try {
      const response = await backendFetch(`/admin/${resource}/${encodeURIComponent(row.id)}`, {
        method: "PATCH",
        body: JSON.stringify({
          seo_title: row.seo_title || null,
          seo_description: row.seo_description || null,
          canonical_url: row.canonical_url || null,
          indexable: row.indexable !== false,
          geo_summary: row.geo_summary || null
        })
      });
      if (!response.ok) throw new Error((await response.text()) || "Save failed");
      setMessage(`Search metadata saved for ${row.name || row.title || row.slug || row.id}.`);
    } catch (error) { setMessage(error instanceof Error ? error.message : "Could not save metadata."); }
    finally { setSaving(""); }
  }

  const missing = rows.filter((row) => !row.seo_title?.trim() || !row.seo_description?.trim());
  const unreviewed = rows.filter((row) => !["APPROVED", "PUBLISHED"].includes(String(row.content_review_status || row.status || "").toUpperCase()));

  return <section className="rounded-[28px] border border-[#f1dfce] bg-white p-5 shadow-sm md:p-8">
    <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#F5A623]">Content & discovery</p>
    <h1 className="mt-2 text-3xl font-bold text-[#0D0D0D]">SEO · AEO · GEO</h1>
    <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">Manage search metadata and AI-discovery context for tests, packages and educational articles. Metadata quality checks are not search ranking or AI citation guarantees.</p>
    <div className="mt-6 grid gap-3 sm:grid-cols-3">
      <div className="rounded-2xl bg-orange-50 p-4"><p className="text-xs font-semibold uppercase text-slate-600">Catalog/content records</p><p className="mt-2 text-3xl font-bold">{rows.length}</p></div>
      <div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-semibold uppercase text-slate-600">Missing title or description</p><p className="mt-2 text-3xl font-bold">{missing.length}</p></div>
      <div className="rounded-2xl bg-slate-50 p-4"><p className="text-xs font-semibold uppercase text-slate-600">Needs review</p><p className="mt-2 text-3xl font-bold">{unreviewed.length}</p></div>
    </div>
    <div className="mt-5 flex justify-end"><button onClick={() => void load()} className="rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold">Refresh content</button></div>
    {message ? <p role="status" className="mt-3 rounded-xl bg-orange-50 p-3 text-sm">{message}</p> : null}
    {loading ? <p className="mt-5 text-sm text-slate-500">Loading content records…</p> : <div className="mt-5 space-y-4">{rows.map((row) => <article key={`${(row as ContentRow & { _type?: string })._type}-${row.id}`} className="rounded-2xl border border-slate-200 p-4">
      <div className="flex flex-wrap items-center justify-between gap-2"><div><p className="text-xs font-semibold uppercase tracking-wide text-[#F5A623]">{(row as ContentRow & { _type?: string })._type}</p><h2 className="mt-1 font-bold text-slate-900">{row.name || row.title || row.slug}</h2><p className="mt-1 text-xs text-slate-500">/{row.slug || row.id}</p></div><span className={`rounded-full px-3 py-1 text-xs font-semibold ${row.seo_title && row.seo_description ? "bg-emerald-50 text-emerald-700" : "bg-orange-50 text-orange-800"}`}>{row.seo_title && row.seo_description ? "Metadata present" : "Metadata incomplete"}</span></div>
      <div className="mt-4 grid gap-3 md:grid-cols-2"><label className="text-xs font-semibold text-slate-600">SEO title<input value={row.seo_title || ""} onChange={(e) => patch(row.id, "seo_title", e.target.value)} maxLength={70} className="mt-1 w-full rounded-lg border p-2 text-sm" placeholder="Page title for search" /></label><label className="text-xs font-semibold text-slate-600">Canonical URL<input value={row.canonical_url || ""} onChange={(e) => patch(row.id, "canonical_url", e.target.value)} className="mt-1 w-full rounded-lg border p-2 text-sm" placeholder="https://www.scopexdiagnostics.in/..." /></label><label className="text-xs font-semibold text-slate-600 md:col-span-2">Meta description<textarea value={row.seo_description || ""} onChange={(e) => patch(row.id, "seo_description", e.target.value)} maxLength={180} rows={2} className="mt-1 w-full rounded-lg border p-2 text-sm" placeholder="Clear, accurate summary for search results" /></label><label className="text-xs font-semibold text-slate-600 md:col-span-2">GEO / AI discovery summary<textarea value={row.geo_summary || ""} onChange={(e) => patch(row.id, "geo_summary", e.target.value)} rows={2} className="mt-1 w-full rounded-lg border p-2 text-sm" placeholder="Factual, approved summary of this test/package/article" /></label></div>
      <div className="mt-3 flex flex-wrap items-center justify-between gap-3"><label className="flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" checked={row.indexable !== false} onChange={(e) => patch(row.id, "indexable", e.target.checked)} /> Allow search indexing</label><button disabled={saving === row.id} onClick={() => void save(row)} className="rounded-xl bg-[#0D0D0D] px-4 py-2 text-sm font-semibold text-white disabled:opacity-50">{saving === row.id ? "Saving…" : "Save metadata"}</button></div>
    </article>)}</div>}
    <p className="mt-5 text-xs leading-5 text-slate-500">Medical content, FAQs and schema must be checked against approved clinical sources before publication. Do not publish unreviewed generated clinical guidance.</p>
  </section>;
}
