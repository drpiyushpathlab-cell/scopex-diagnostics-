"use client";

import { useCallback, useEffect, useState } from "react";
import { getStoredAuthToken } from "@/lib/backend-client";

type Lead = {
  id: string;
  lead_type?: string;
  name?: string;
  phone?: string;
  mobile?: string;
  mobile_number?: string;
  email?: string;
  city?: string;
  state?: string;
  purpose?: string;
  source?: string;
  campaign?: string;
  status?: string;
  lead_status?: string;
  priority?: string;
  assigned_user_id?: string | null;
  assigned_team?: string | null;
  next_follow_up_at?: string | null;
  created_at?: string;
};
type AssignmentSetting = { id: string; workflow: string; assignment_mode: "manual" | "automatic"; active: boolean; rules?: Record<string, unknown> };

const statuses = ["New", "Contacted", "Qualified", "Follow-up", "Booking Pending", "Converted", "Not Interested", "Closed"];
const priorities = ["low", "normal", "high", "urgent"];

export function AdminCrm() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [settings, setSettings] = useState<AssignmentSetting[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState("");
  const [message, setMessage] = useState("");
  const [query, setQuery] = useState("");

  const api = useCallback(async (method: "GET" | "PATCH", body?: Record<string, unknown>) => {
    const token = getStoredAuthToken();
    const response = await fetch("/api/admin/crm", {
      method,
      headers: { ...(token ? { Authorization: `Bearer ${token}` } : {}), ...(body ? { "Content-Type": "application/json" } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      cache: "no-store"
    });
    const data = await response.json().catch(() => ({}));
    if (!response.ok) throw new Error(data.message || "CRM request failed.");
    return data;
  }, []);

  const load = useCallback(async () => {
    setLoading(true);
    try {
      const data = await api("GET");
      setLeads(data.leads ?? []);
      setSettings(data.settings ?? []);
      setMessage("");
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to load CRM.");
    } finally { setLoading(false); }
  }, [api]);

  useEffect(() => { void load(); }, [load]);

  async function updateLead(lead: Lead, patch: Record<string, unknown>) {
    setSavingId(lead.id); setMessage("");
    try {
      await api("PATCH", { type: "lead", id: lead.id, ...patch });
      setMessage(`Lead updated: ${lead.name || lead.id}`);
      await load();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to update lead."); }
    finally { setSavingId(""); }
  }

  async function setMode(setting: AssignmentSetting, mode: "manual" | "automatic") {
    setMessage("");
    try {
      await api("PATCH", { type: "settings", workflow: setting.workflow, assignment_mode: mode, active: true });
      setMessage(`${setting.workflow === "crm_leads" ? "CRM lead assignment" : "Phlebotomist allocation"} set to ${mode} mode.`);
      await load();
    } catch (error) { setMessage(error instanceof Error ? error.message : "Unable to change assignment mode."); }
  }

  const visibleLeads = leads.filter((lead) => `${lead.name} ${lead.mobile_number} ${lead.phone} ${lead.city} ${lead.source} ${lead.lead_status}`.toLowerCase().includes(query.toLowerCase()));
  const settingFor = (workflow: string) => settings.find((item) => item.workflow === workflow);

  return <section className="rounded-[28px] border border-[#f1dfce] bg-white p-5 shadow-sm md:p-8">
    <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#F5A623]">Customer relationship management</p>
    <h1 className="mt-2 text-3xl font-bold text-[#0D0D0D]">CRM & lead routing</h1>
    <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">Manage captured leads, status, follow-up, owner and routing mode. Automatic lead routing uses the least-open-leads strategy for eligible customer-care and booking staff; when no eligible staff are available, leads remain unassigned.</p>
    <div className="mt-6 grid gap-4 md:grid-cols-2">{["crm_leads", "phlebotomist_jobs"].map((workflow) => { const setting = settingFor(workflow); return <article key={workflow} className="rounded-2xl border border-slate-200 p-4"><p className="text-xs font-semibold uppercase tracking-wide text-slate-500">{workflow === "crm_leads" ? "Lead assignment" : "Phlebotomist allocation"}</p><p className="mt-2 text-lg font-bold text-slate-900">{setting?.assignment_mode === "automatic" ? "Automatic mode" : "Manual mode"}</p><div className="mt-3 flex flex-wrap gap-2"><button disabled={!setting || setting.assignment_mode === "manual"} onClick={() => setting && void setMode(setting, "manual")} className={`rounded-lg px-3 py-2 text-sm font-semibold ${setting?.assignment_mode === "manual" ? "bg-[#0D0D0D] text-white" : "border border-slate-200"}`}>Manual</button><button disabled={!setting || setting.assignment_mode === "automatic"} onClick={() => setting && void setMode(setting, "automatic")} className={`rounded-lg px-3 py-2 text-sm font-semibold ${setting?.assignment_mode === "automatic" ? "bg-[#F5A623] text-[#0D0D0D]" : "border border-slate-200"}`}>Automatic</button></div></article>; })}</div>
    <div className="mt-6 flex flex-wrap gap-3"><input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search lead, phone, city or source" className="min-w-[240px] flex-1 rounded-xl border border-slate-300 px-4 py-2 text-sm" /><button onClick={() => void load()} className="rounded-xl border border-slate-200 px-4 py-2 text-sm font-semibold">Refresh leads</button></div>
    {message ? <p role="status" className="mt-3 rounded-xl bg-orange-50 p-3 text-sm">{message}</p> : null}
    {loading ? <p className="mt-5 text-sm text-slate-500">Loading CRM leads…</p> : <div className="mt-5 space-y-4">{visibleLeads.length === 0 ? <p className="rounded-xl border border-dashed p-6 text-sm text-slate-500">No matching leads found.</p> : visibleLeads.map((lead) => <article key={lead.id} className="rounded-2xl border border-slate-200 p-4">
      <div className="flex flex-wrap items-start justify-between gap-3"><div><h2 className="font-bold text-slate-900">{lead.name || "Unnamed lead"}</h2><p className="mt-1 text-sm text-slate-600">{lead.mobile_number || lead.phone || lead.mobile || "No phone"}{lead.email ? ` · ${lead.email}` : ""}</p><p className="mt-1 text-xs text-slate-500">{lead.city || "City not supplied"}{lead.state ? `, ${lead.state}` : ""} · Source: {lead.source || "website"} · {lead.lead_type || "general"}</p></div><span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold">{lead.created_at ? new Date(lead.created_at).toLocaleString("en-IN") : "Date unavailable"}</span></div>
      <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4"><label className="text-xs font-semibold text-slate-600">Lead status<select value={lead.lead_status || "New"} onChange={(e) => void updateLead(lead, { lead_status: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm text-slate-900">{statuses.map((status) => <option key={status}>{status}</option>)}</select></label><label className="text-xs font-semibold text-slate-600">Priority<select value={lead.priority || "normal"} onChange={(e) => void updateLead(lead, { priority: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm text-slate-900">{priorities.map((priority) => <option key={priority} value={priority}>{priority}</option>)}</select></label><label className="text-xs font-semibold text-slate-600">Assigned staff user ID<input defaultValue={lead.assigned_user_id || ""} key={`${lead.id}-${lead.assigned_user_id || "none"}`} onBlur={(e) => { const value = e.target.value.trim() || null; if (value !== (lead.assigned_user_id || null)) void updateLead(lead, { assigned_user_id: value, assigned_team: "customer_support" }); }} placeholder="UUID for staff user" className="mt-1 w-full rounded-lg border p-2 text-sm text-slate-900" /></label><label className="text-xs font-semibold text-slate-600">Next follow-up<input type="datetime-local" value={lead.next_follow_up_at ? new Date(lead.next_follow_up_at).toISOString().slice(0, 16) : ""} onChange={(e) => void updateLead(lead, { next_follow_up_at: e.target.value ? new Date(e.target.value).toISOString() : null })} className="mt-1 w-full rounded-lg border p-2 text-sm text-slate-900" /></label></div>
      {savingId === lead.id ? <p className="mt-3 text-xs text-slate-500">Saving update…</p> : null}
    </article>)}</div>}
  </section>;
}
