"use client";

import { useCallback, useEffect, useState } from "react";
import { backendFetch } from "@/lib/backend-client";

type CatalogRow = {
  id: string;
  name: string;
  slug?: string;
  price?: number | string;
  real_price?: number | string | null;
  mrp?: number | string;
  discount?: number | string;
  max_discount_percent?: number | string | null;
  max_discount_amount?: number | string | null;
  bundle_discount_eligible?: boolean;
  package_type?: string;
  is_active?: boolean;
  active?: boolean;
};

type BundleRuleRow = {
  id: string;
  name: string;
  code: string;
  min_eligible_test_count: number;
  min_eligible_spend?: number;
  discount_type: "PERCENT" | "FIXED";
  discount_value: number;
  max_saving?: number | null;
  active: boolean;
};

const money = (value: unknown) => `₹${new Intl.NumberFormat("en-IN", { maximumFractionDigits: 2 }).format(Number(value || 0))}`;

export function AdminCatalogPricing() {
  const [tab, setTab] = useState<"tests" | "packages" | "rules">("tests");
  const [tests, setTests] = useState<CatalogRow[]>([]);
  const [packages, setPackages] = useState<CatalogRow[]>([]);
  const [rules, setRules] = useState<BundleRuleRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [savingId, setSavingId] = useState("");
  const [message, setMessage] = useState("");
  const [newRule, setNewRule] = useState({ name: "Bundle saving", code: "BUNDLE_2", min_eligible_test_count: "2", discount_type: "PERCENT", discount_value: "5", max_saving: "" });

  const load = useCallback(async () => {
    setLoading(true);
    setMessage("");
    try {
      const [testRes, packageRes, ruleRes] = await Promise.all([
        backendFetch("/admin/tests"), backendFetch("/admin/packages"), backendFetch("/admin/bundle_rules")
      ]);
      const [testJson, packageJson, ruleJson] = await Promise.all([
        testRes.json().catch(() => ({})), packageRes.json().catch(() => ({})), ruleRes.json().catch(() => ({}))
      ]);
      if (testRes.ok) setTests(testJson.data ?? []);
      if (packageRes.ok) setPackages(packageJson.data ?? []);
      if (ruleRes.ok) setRules(ruleJson.data ?? []);
      if (![testRes, packageRes, ruleRes].some((res) => res.ok)) setMessage("Could not load catalog. Confirm admin login, database migrations and backend configuration.");
    } catch {
      setMessage("Backend is not reachable. Start the backend and confirm your admin session.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { void load(); }, [load]);

  async function saveRow(kind: "tests" | "packages", row: CatalogRow) {
    setSavingId(row.id);
    setMessage("");
    const payload = {
      real_price: Number(row.real_price ?? row.price ?? 0),
      max_discount_percent: row.max_discount_percent === "" || row.max_discount_percent == null ? null : Number(row.max_discount_percent),
      max_discount_amount: row.max_discount_amount === "" || row.max_discount_amount == null ? null : Number(row.max_discount_amount),
      bundle_discount_eligible: Boolean(row.bundle_discount_eligible),
      ...(kind === "packages" ? { package_type: row.package_type || "fixed" } : {})
    };
    try {
      const response = await backendFetch(`/admin/${kind}/${encodeURIComponent(row.id)}`, { method: "PATCH", body: JSON.stringify(payload) });
      if (!response.ok) throw new Error((await response.text()) || "Save failed");
      setMessage(`${row.name} updated successfully.`);
      await load();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to save changes.");
    } finally {
      setSavingId("");
    }
  }

  async function createRule() {
    setMessage("");
    try {
      const response = await backendFetch("/admin/bundle_rules", {
        method: "POST",
        body: JSON.stringify({
          name: newRule.name.trim(), code: newRule.code.trim().toUpperCase(),
          min_eligible_test_count: Number(newRule.min_eligible_test_count),
          min_eligible_spend: 0, discount_type: newRule.discount_type,
          discount_value: Number(newRule.discount_value),
          max_saving: newRule.max_saving ? Number(newRule.max_saving) : null,
          applies_to_fixed_packages: false, applies_to_custom_packages: true,
          stack_policy: "exclusive", active: true
        })
      });
      if (!response.ok) throw new Error((await response.text()) || "Could not create rule");
      setMessage("Bundle discount slab created.");
      await load();
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "Unable to create bundle rule.");
    }
  }

  function updateRow(kind: "tests" | "packages", id: string, patch: Partial<CatalogRow>) {
    const setter = kind === "tests" ? setTests : setPackages;
    setter((rows) => rows.map((row) => row.id === id ? { ...row, ...patch } : row));
  }

  const rows = tab === "tests" ? tests : packages;

  return (
    <section className="rounded-[28px] border border-[#f1dfce] bg-white p-5 shadow-sm md:p-8">
      <p className="text-sm font-semibold uppercase tracking-[0.18em] text-[#F5A623]">Admin · Catalog</p>
      <h1 className="mt-2 text-3xl font-bold text-[#0D0D0D]">Catalog & pricing engine</h1>
      <p className="mt-2 max-w-3xl text-sm leading-6 text-slate-600">Manage real selling prices, per-test discount caps and bundle slabs. Fixed packages do not receive custom-test bundle discounts unless explicitly enabled.</p>
      <div className="mt-6 flex flex-wrap gap-2">
        {([['tests', 'Tests'], ['packages', 'Fixed packages'], ['rules', 'Bundle discount slabs']] as const).map(([value, label]) => (
          <button key={value} onClick={() => setTab(value)} className={`rounded-full px-4 py-2 text-sm font-semibold ${tab === value ? 'bg-[#0D0D0D] text-white' : 'border border-slate-200 text-slate-700'}`}>{label}</button>
        ))}
        <button onClick={() => void load()} className="ml-auto rounded-full border border-slate-200 px-4 py-2 text-sm font-semibold">Refresh</button>
      </div>
      {message ? <p role="status" className="mt-4 rounded-xl bg-orange-50 p-3 text-sm text-slate-800">{message}</p> : null}
      {loading ? <p className="mt-6 text-sm text-slate-500">Loading live catalog data…</p> : null}

      {tab !== "rules" && !loading ? (
        <div className="mt-5 space-y-4">
          {rows.length === 0 ? <p className="rounded-xl border border-dashed p-6 text-sm text-slate-500">No records returned. Check the database migration and seed data.</p> : null}
          {rows.map((row) => (
            <article key={row.id} className="rounded-2xl border border-slate-200 p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div><h2 className="font-bold text-slate-900">{row.name}</h2><p className="mt-1 text-xs text-slate-500">ID: {row.id} · Reference price: {money(row.mrp)}</p></div>
                <span className="rounded-full bg-slate-100 px-3 py-1 text-xs font-semibold">{tab === "tests" ? "Test" : "Fixed package"}</span>
              </div>
              <div className="mt-4 grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                <label className="text-xs font-semibold text-slate-600">Real selling price (₹)<input type="number" min="0" step="1" value={row.real_price ?? row.price ?? 0} onChange={(e) => updateRow(tab, row.id, { real_price: e.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm text-slate-900" /></label>
                <label className="text-xs font-semibold text-slate-600">Maximum discount (%)<input type="number" min="0" max="100" step="0.1" value={row.max_discount_percent ?? ""} onChange={(e) => updateRow(tab, row.id, { max_discount_percent: e.target.value })} placeholder="No cap" className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm text-slate-900" /></label>
                <label className="text-xs font-semibold text-slate-600">Maximum discount (₹)<input type="number" min="0" step="1" value={row.max_discount_amount ?? ""} onChange={(e) => updateRow(tab, row.id, { max_discount_amount: e.target.value })} placeholder="No cap" className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm text-slate-900" /></label>
                {tab === "packages" ? <label className="text-xs font-semibold text-slate-600">Package type<select value={row.package_type || "fixed"} onChange={(e) => updateRow(tab, row.id, { package_type: e.target.value })} className="mt-1 w-full rounded-lg border border-slate-300 p-2 text-sm text-slate-900"><option value="fixed">Fixed package</option><option value="custom">Custom package template</option></select></label> : <label className="flex items-center gap-2 self-center text-sm text-slate-700"><input type="checkbox" checked={row.bundle_discount_eligible !== false} onChange={(e) => updateRow(tab, row.id, { bundle_discount_eligible: e.target.checked })} /> Eligible for bundle discount</label>}
              </div>
              {tab === "packages" ? <label className="mt-3 flex items-center gap-2 text-sm text-slate-700"><input type="checkbox" checked={Boolean(row.bundle_discount_eligible)} onChange={(e) => updateRow(tab, row.id, { bundle_discount_eligible: e.target.checked })} /> Allow additional bundle discount (off by default)</label> : null}
              <div className="mt-4 flex flex-wrap items-center justify-between gap-3"><p className="text-sm text-slate-600">Preview price: <strong className="text-slate-900">{money(row.real_price ?? row.price)}</strong></p><button disabled={savingId === row.id} onClick={() => void saveRow(tab, row)} className="rounded-xl bg-[#F5A623] px-4 py-2 text-sm font-bold text-[#0D0D0D] disabled:opacity-50">{savingId === row.id ? "Saving…" : "Save changes"}</button></div>
            </article>
          ))}
        </div>
      ) : null}

      {tab === "rules" && !loading ? <div className="mt-5 grid gap-5 lg:grid-cols-[1fr_1.2fr]">
        <form className="rounded-2xl border border-slate-200 p-4" onSubmit={(e) => { e.preventDefault(); void createRule(); }}>
          <h2 className="font-bold text-slate-900">Add bundle slab</h2>
          <div className="mt-4 space-y-3">
            <label className="block text-xs font-semibold text-slate-600">Rule name<input required value={newRule.name} onChange={(e) => setNewRule({ ...newRule, name: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm" /></label>
            <label className="block text-xs font-semibold text-slate-600">Unique code<input required value={newRule.code} onChange={(e) => setNewRule({ ...newRule, code: e.target.value.toUpperCase() })} className="mt-1 w-full rounded-lg border p-2 text-sm" /></label>
            <label className="block text-xs font-semibold text-slate-600">Minimum eligible test count<input required type="number" min="1" value={newRule.min_eligible_test_count} onChange={(e) => setNewRule({ ...newRule, min_eligible_test_count: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm" /></label>
            <label className="block text-xs font-semibold text-slate-600">Discount type<select value={newRule.discount_type} onChange={(e) => setNewRule({ ...newRule, discount_type: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm"><option value="PERCENT">Percentage</option><option value="FIXED">Fixed amount</option></select></label>
            <label className="block text-xs font-semibold text-slate-600">Discount value<input required type="number" min="0" step="0.1" value={newRule.discount_value} onChange={(e) => setNewRule({ ...newRule, discount_value: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm" /></label>
            <label className="block text-xs font-semibold text-slate-600">Maximum total saving (₹, optional)<input type="number" min="0" value={newRule.max_saving} onChange={(e) => setNewRule({ ...newRule, max_saving: e.target.value })} className="mt-1 w-full rounded-lg border p-2 text-sm" /></label>
          </div>
          <button type="submit" className="mt-4 w-full rounded-xl bg-[#0D0D0D] px-4 py-3 text-sm font-bold text-white">Create slab</button>
          <p className="mt-3 text-xs leading-5 text-slate-500">New slabs are exclusive by default and apply to eligible custom test carts. Confirm that backend checkout uses the same rules and per-test caps.</p>
        </form>
        <div className="space-y-3">{rules.length === 0 ? <p className="rounded-xl border border-dashed p-5 text-sm text-slate-500">No saved bundle rules found.</p> : rules.map((rule) => <article key={rule.id} className="rounded-2xl border border-slate-200 p-4"><div className="flex items-start justify-between gap-3"><div><h3 className="font-bold text-slate-900">{rule.name}</h3><p className="mt-1 text-xs text-slate-500">{rule.code} · {rule.min_eligible_test_count}+ tests</p></div><span className={`rounded-full px-3 py-1 text-xs font-bold ${rule.active ? "bg-emerald-50 text-emerald-700" : "bg-slate-100 text-slate-600"}`}>{rule.active ? "Active" : "Inactive"}</span></div><p className="mt-3 text-sm text-slate-700">{rule.discount_type === "PERCENT" ? `${rule.discount_value}% off` : `${money(rule.discount_value)} off`}{rule.max_saving != null ? ` · Max ${money(rule.max_saving)}` : ""}</p></article>)}</div>
      </div> : null}
    </section>
  );
}
