-- SCOPEX final additive migration for the existing InsForge-compatible schema.
-- Run this against the same database used by backend/src/lib/insforge.ts.

alter table tests add column if not exists real_price numeric(10,2);
alter table tests add column if not exists max_discount_percent numeric(5,2);
alter table tests add column if not exists max_discount_amount numeric(10,2);
alter table tests add column if not exists bundle_discount_eligible boolean not null default true;
alter table tests add column if not exists seo_title text;
alter table tests add column if not exists seo_description text;
alter table tests add column if not exists seo_keywords text[] not null default '{}';
alter table tests add column if not exists canonical_url text;
alter table tests add column if not exists indexable boolean not null default true;
alter table tests add column if not exists faq_json jsonb not null default '[]'::jsonb;
alter table tests add column if not exists answer_blocks_json jsonb not null default '[]'::jsonb;
alter table tests add column if not exists geo_summary text;
alter table tests add column if not exists content_review_status text not null default 'DRAFT';

alter table packages add column if not exists real_price numeric(10,2);
alter table packages add column if not exists package_type text not null default 'fixed';
alter table packages add column if not exists max_discount_percent numeric(5,2);
alter table packages add column if not exists max_discount_amount numeric(10,2);
alter table packages add column if not exists bundle_discount_eligible boolean not null default false;
alter table packages add column if not exists seo_title text;
alter table packages add column if not exists seo_description text;
alter table packages add column if not exists seo_keywords text[] not null default '{}';
alter table packages add column if not exists canonical_url text;
alter table packages add column if not exists indexable boolean not null default true;
alter table packages add column if not exists faq_json jsonb not null default '[]'::jsonb;
alter table packages add column if not exists answer_blocks_json jsonb not null default '[]'::jsonb;
alter table packages add column if not exists geo_summary text;
alter table packages add column if not exists content_review_status text not null default 'DRAFT';

create table if not exists bundle_rules (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  code text not null unique,
  min_eligible_test_count integer not null default 2 check (min_eligible_test_count > 0),
  min_eligible_spend numeric(10,2) not null default 0 check (min_eligible_spend >= 0),
  discount_type text not null check (discount_type in ('PERCENT','FIXED')),
  discount_value numeric(10,2) not null check (discount_value >= 0),
  max_saving numeric(10,2) check (max_saving is null or max_saving >= 0),
  applies_to_fixed_packages boolean not null default false,
  applies_to_custom_packages boolean not null default true,
  stack_policy text not null default 'exclusive' check (stack_policy in ('exclusive','stack_allowed')),
  starts_at timestamptz,
  ends_at timestamptz,
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

alter table leads add column if not exists lead_status text not null default 'New';
alter table leads add column if not exists priority text not null default 'normal';
alter table leads add column if not exists campaign text;
alter table leads add column if not exists interested_tests jsonb not null default '[]'::jsonb;
alter table leads add column if not exists interested_packages jsonb not null default '[]'::jsonb;
alter table leads add column if not exists contact_consent boolean not null default false;
alter table leads add column if not exists assigned_user_id uuid;
alter table leads add column if not exists assigned_team text;
alter table leads add column if not exists next_follow_up_at timestamptz;
alter table leads add column if not exists last_contacted_at timestamptz;
alter table leads add column if not exists updated_at timestamptz not null default now();

create table if not exists lead_activity_log (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references leads(id) on delete cascade,
  activity_type text not null,
  old_value jsonb,
  new_value jsonb,
  note text,
  actor_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists assignment_settings (
  id uuid primary key default gen_random_uuid(),
  workflow text not null unique check (workflow in ('crm_leads','phlebotomist_jobs')),
  assignment_mode text not null default 'manual' check (assignment_mode in ('manual','automatic')),
  rules jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  updated_at timestamptz not null default now()
);

insert into assignment_settings (workflow, assignment_mode, rules)
values ('crm_leads','manual','{"fallback":"unassigned_queue"}'::jsonb),
       ('phlebotomist_jobs','manual','{"fallback":"exception_queue"}'::jsonb)
on conflict (workflow) do nothing;

create index if not exists tests_bundle_eligible_idx on tests(bundle_discount_eligible, is_active);
create index if not exists packages_type_active_idx on packages(package_type, is_active);
create index if not exists leads_status_followup_idx on leads(lead_status, next_follow_up_at);
create index if not exists leads_assignment_idx on leads(assigned_team, assigned_user_id, lead_status);
create index if not exists lead_activity_log_lead_idx on lead_activity_log(lead_id, created_at desc);

create table if not exists blog_posts (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique,
  title text not null,
  excerpt text,
  body_md text not null default '',
  status text not null default 'DRAFT',
  seo_title text,
  seo_description text,
  seo_keywords text[] not null default '{}',
  canonical_url text,
  indexable boolean not null default true,
  faq_json jsonb not null default '[]'::jsonb,
  answer_blocks_json jsonb not null default '[]'::jsonb,
  geo_summary text,
  source_references jsonb not null default '[]'::jsonb,
  content_review_status text not null default 'DRAFT',
  medical_reviewer_id uuid,
  medically_reviewed_at timestamptz,
  published_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index if not exists blog_posts_status_published_idx on blog_posts(status, published_at desc);
