# SCOPEX Diagnostics Backend + Website

Production-ready ScopeX Diagnostics platform with a Next.js marketing/booking frontend and a Node.js + Express backend powered by InsForge-style database APIs.

## Stack

- Next.js App Router
- Tailwind CSS
- Node.js + Express backend
- InsForge database SDK
- MSG91 OTP login
- Razorpay orders and payment verification
- Google Sheets + email lead notification

## Core Frontend Routes

- `/` landing page
- `/book-home-collection` booking flow
- `/patient/login` OTP login
- `/patient` patient dashboard shell
- `/admin/login` admin login
- `/admin` admin overview
- `/packages`
- `/tests`
- `/health-advisor`

## Backend Routes

- `POST /auth/send-otp`
- `POST /auth/verify-otp`
- `POST /auth/admin/login`
- `POST /family/add`
- `GET /family/list`
- `GET /tests`
- `GET /packages`
- `POST /booking/create`
- `GET /booking/user`
- `GET /booking/history`
- `POST /payment/create-order`
- `POST /payment/verify`
- `GET /report/:id`
- `GET /admin/dashboard`
- `GET /admin/:resource`
- `POST /admin/:resource`
- `PATCH /admin/:resource/:id`
- `DELETE /admin/:resource/:id`

Admin resources: `tests`, `packages`, `offers`, `bookings`.

## Database

Apply the InsForge-compatible SQL schema:

- [`backend/schema.infoge.sql`](C:\Users\dell\OneDrive\Desktop\2 page scopex web\backend\schema.infoge.sql)
- [`backend/seed-catalog.infoge.sql`](C:\Users\dell\OneDrive\Desktop\2 page scopex web\backend\seed-catalog.infoge.sql)

Tables included:

- `users`
- `patients`
- `family_members`
- `tests`
- `packages`
- `package_tests`
- `bookings`
- `booking_items`
- `payments`
- `offers`
- `admins`
- `otp_logs`
- `otp_verification`
- `reports`
- `memberships`
- `referrals`

## Local Setup

1. Install dependencies:
   ```bash
   npm install
   ```

2. Copy environment file:
   ```bash
   cp .env.example .env.local
   ```

3. Start backend:
   ```bash
   npm run dev:backend
   ```

4. Start frontend:
   ```bash
   npm run dev
   ```

Frontend runs on `http://localhost:3000`.
Backend runs on `http://localhost:4000`.

## Build Checks

```bash
npm run build
npm run build:backend
```

## Deployment Notes

- Deploy the Next.js frontend to Vercel with `npm run build`.
- Deploy the Express backend as a Node service.
- Set `NEXT_PUBLIC_BACKEND_URL` to the backend URL in Vercel.
- Keep all secrets in environment variables only.

## Final catalog, pricing, CRM and AI-search additions

New admin routes:

- `/admin/catalog-pricing` — edit real selling prices, per-test discount caps, fixed package bundle eligibility, and bundle discount slabs.
- `/admin/content-search` — manage SEO title/description, canonical URL, indexing preference and GEO/AI-discovery summary for tests, packages and articles.
- `/admin/crm` — review captured website leads, update lead status/priority, set follow-ups, assign a staff UUID, and configure manual/automatic CRM lead assignment.

Pricing engine additions in `lib/pricing.ts`:

- Per-test maximum discount percentage and/or fixed-rupee cap.
- Automatic bundle slab selection with date and minimum-spend checks.
- Fixed packages excluded from test-cart bundle discounts by default.
- Total promotion caps, savings amount/percentage and per-item discount breakdown.
- Unit smoke tests are included in `tests/pricing.test.ts`.

### Database migration steps

1. Apply the existing Supabase migrations in timestamp order, including `migrations/20261021100000_scopex_pricing_crm_ai_search.sql`.
2. If the current Express backend is still using the InsForge-compatible database configured by `INSFORGE_BASE_URL`, apply `backend/scopex-final-migration.sql` to that database as well.
3. Configure `SUPABASE_SERVICE_ROLE_KEY` only on the server, plus `APP_JWT_SECRET`, Supabase URL, backend URL and the required provider credentials.
4. Review role permissions before granting catalog, pricing, CRM or content access to staff accounts.
5. Test in staging before production. The admin CRM lead view uses Supabase because the existing website lead-capture route stores leads there; the legacy Express catalog/admin APIs use the InsForge-compatible database. If both services remain enabled, keep both migrations aligned or consolidate to one authoritative database before launch.

Automatic CRM assignment uses the least-open-leads strategy when the Supabase `assignment_settings` row is active and eligible `admin_roles` users exist. If no eligible staff are found, a lead is saved unassigned. The phlebotomist assignment mode is stored as configuration; automatic dispatch still needs to be connected to the live booking/collection allocation workflow before it should be enabled operationally.

Full dependency installation and production build could not be verified in this environment because the package registry was unreachable. TypeScript/TSX syntax parsing and pricing smoke checks were run successfully; run `npm ci`, `npm run test:pricing`, `npm run build` and `npm run build:backend` in your development environment before deployment.
