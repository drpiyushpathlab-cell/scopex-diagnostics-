-- ScopeX Diagnostics: per-test discount caps, package modes, CRM routing and AI-search content.
-- Additive migration: preserves existing catalog, booking and lead records.

-- Tests: real-price and per-test promotion controls.
alter table public.tests add column if not exists max_discount_percent numeric(5,2);
alter table public.tests add column if not exists max_discount_amount numeric(10,2);
alter table public.tests add column if not exists bundle_discount_eligible boolean not null default true;
alter table public.tests add column if not exists seo_keywords text[] not null default '{}';
alter table public.tests add column if not exists canonical_url text;
alter table public.tests add column if not exists indexable boolean not null default true;
alter table public.tests add column if not exists faq_json jsonb not null default '[]'::jsonb;
alter table public.tests add column if not exists answer_blocks_json jsonb not null default '[]'::jsonb;
alter table public.tests add column if not exists geo_summary text;
alter table public.tests add column if not exists content_review_status text not null default 'DRAFT'
  check (content_review_status in ('DRAFT','IN_REVIEW','APPROVED','UPDATE_REQUIRED'));
alter table public.tests add column if not exists content_reviewed_by uuid references auth.users(id) on delete set null;
alter table public.tests add column if not exists content_reviewed_at timestamptz;

-- Fixed packages remain predefined. Customer-built custom packages are carts of test lines,
-- not mutable catalog packages. A fixed package receives bundle discounts only when enabled.
alter table public.packages add column if not exists package_type text not null default 'fixed'
  check (package_type in ('fixed','custom'));
alter table public.packages add column if not exists max_discount_percent numeric(5,2);
alter table public.packages add column if not exists max_discount_amount numeric(10,2);
alter table public.packages add column if not exists bundle_discount_eligible boolean not null default false;
alter table public.packages add column if not exists seo_keywords text[] not null default '{}';
alter table public.packages add column if not exists canonical_url text;
alter table public.packages add column if not exists indexable boolean not null default true;
alter table public.packages add column if not exists faq_json jsonb not null default '[]'::jsonb;
alter table public.packages add column if not exists answer_blocks_json jsonb not null default '[]'::jsonb;
alter table public.packages add column if not exists geo_summary text;
alter table public.packages add column if not exists content_review_status text not null default 'DRAFT'
  check (content_review_status in ('DRAFT','IN_REVIEW','APPROVED','UPDATE_REQUIRED'));
alter table public.packages add column if not exists content_reviewed_by uuid references auth.users(id) on delete set null;
alter table public.packages add column if not exists content_reviewed_at timestamptz;

-- Bundle rules: make eligibility and total-cap behavior explicit.
alter table public.bundle_rules add column if not exists min_eligible_spend numeric(10,2) not null default 0
  check (min_eligible_spend >= 0);
alter table public.bundle_rules add column if not exists max_total_saving numeric(10,2)
  check (max_total_saving is null or max_total_saving >= 0);
alter table public.bundle_rules add column if not exists applies_to_fixed_packages boolean not null default false;
alter table public.bundle_rules add column if not exists applies_to_custom_packages boolean not null default true;
alter table public.bundle_rules add column if not exists stack_policy text not null default 'exclusive'
  check (stack_policy in ('exclusive','stack_allowed'));

-- Blogs and educational content: AEO/GEO fields plus explicit human review.
alter table public.blog_posts add column if not exists seo_keywords text[] not null default '{}';
alter table public.blog_posts add column if not exists canonical_url text;
alter table public.blog_posts add column if not exists indexable boolean not null default true;
alter table public.blog_posts add column if not exists faq_json jsonb not null default '[]'::jsonb;
alter table public.blog_posts add column if not exists answer_blocks_json jsonb not null default '[]'::jsonb;
alter table public.blog_posts add column if not exists geo_summary text;
alter table public.blog_posts add column if not exists source_references jsonb not null default '[]'::jsonb;
alter table public.blog_posts add column if not exists content_review_status text not null default 'DRAFT'
  check (content_review_status in ('DRAFT','IN_REVIEW','APPROVED','UPDATE_REQUIRED'));
alter table public.blog_posts add column if not exists content_reviewed_by uuid references auth.users(id) on delete set null;
alter table public.blog_posts add column if not exists content_reviewed_at timestamptz;

-- CRM lead capture, assignment, transfer and follow-up fields.
-- Create a compatible base table for fresh Supabase installations; existing rows are preserved.
create table if not exists public.leads (
  id uuid primary key default gen_random_uuid(),
  lead_type text not null default 'general',
  name text not null default 'Website lead',
  age integer,
  gender text,
  phone text,
  mobile text,
  mobile_number text not null default '',
  email text,
  official_email text,
  city text,
  state text,
  address text,
  preferred_time text,
  purpose text,
  company_name text,
  contact_person text,
  designation text,
  company_website text,
  business_type text,
  expected_monthly_volume text,
  collection_date text,
  appointment_date text,
  family_members text,
  message text,
  consent boolean not null default false,
  source text not null default 'website',
  status text not null default 'new',
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.leads add column if not exists phone text;
alter table public.leads add column if not exists mobile text;
alter table public.leads add column if not exists email text;
alter table public.leads add column if not exists official_email text;
alter table public.leads add column if not exists status text not null default 'new';
alter table public.leads add column if not exists metadata jsonb not null default '{}'::jsonb;
alter table public.leads add column if not exists age integer;
alter table public.leads add column if not exists gender text;
alter table public.leads add column if not exists state text;
alter table public.leads add column if not exists preferred_time text;
alter table public.leads add column if not exists company_name text;
alter table public.leads add column if not exists contact_person text;
alter table public.leads add column if not exists designation text;
alter table public.leads add column if not exists company_website text;
alter table public.leads add column if not exists business_type text;
alter table public.leads add column if not exists expected_monthly_volume text;
alter table public.leads add column if not exists appointment_date text;
alter table public.leads add column if not exists family_members text;

alter table public.leads add column if not exists lead_status text not null default 'New'
  check (lead_status in ('New','Contacted','Qualified','Follow-up','Booking Pending','Converted','Not Interested','Closed'));
alter table public.leads add column if not exists priority text not null default 'normal'
  check (priority in ('low','normal','high','urgent'));
alter table public.leads add column if not exists campaign text;
alter table public.leads add column if not exists interested_tests jsonb not null default '[]'::jsonb;
alter table public.leads add column if not exists interested_packages jsonb not null default '[]'::jsonb;
alter table public.leads add column if not exists contact_consent boolean not null default false;
alter table public.leads add column if not exists assigned_user_id uuid;
alter table public.leads add column if not exists assigned_team text;
alter table public.leads add column if not exists next_follow_up_at timestamptz;
alter table public.leads add column if not exists last_contacted_at timestamptz;
alter table public.leads add column if not exists updated_at timestamptz not null default now();

create table if not exists public.lead_activity_log (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  activity_type text not null check (activity_type in ('created','status_changed','assigned','transferred','note','contacted','follow_up_set','converted')),
  old_value jsonb,
  new_value jsonb,
  note text,
  actor_id uuid,
  created_at timestamptz not null default now()
);

create table if not exists public.assignment_settings (
  id uuid primary key default gen_random_uuid(),
  workflow text not null unique check (workflow in ('crm_leads','phlebotomist_jobs')),
  assignment_mode text not null default 'manual' check (assignment_mode in ('manual','automatic')),
  rules jsonb not null default '{}'::jsonb,
  active boolean not null default true,
  updated_by uuid references auth.users(id) on delete set null,
  updated_at timestamptz not null default now()
);

insert into public.assignment_settings (workflow, assignment_mode, rules)
values
  ('crm_leads','manual','{"fallback":"unassigned_queue","strategy":"city_then_workload"}'::jsonb),
  ('phlebotomist_jobs','manual','{"fallback":"exception_queue","strategy":"service_area_slot_availability_workload"}'::jsonb)
on conflict (workflow) do nothing;

create table if not exists public.lead_assignment_history (
  id uuid primary key default gen_random_uuid(),
  lead_id uuid not null references public.leads(id) on delete cascade,
  from_user_id uuid,
  to_user_id uuid,
  team text,
  assignment_mode text not null check (assignment_mode in ('manual','automatic')),
  rule_snapshot jsonb not null default '{}'::jsonb,
  assigned_by uuid,
  created_at timestamptz not null default now()
);

create index if not exists tests_bundle_eligible_idx on public.tests(bundle_discount_eligible, active);
create index if not exists packages_type_active_idx on public.packages(package_type, active);
create index if not exists leads_status_followup_idx on public.leads(lead_status, next_follow_up_at);
create index if not exists leads_assignment_idx on public.leads(assigned_team, assigned_user_id, lead_status);
create index if not exists lead_activity_lead_idx on public.lead_activity_log(lead_id, created_at desc);
create index if not exists lead_assignment_history_idx on public.lead_assignment_history(lead_id, created_at desc);

alter table public.lead_activity_log enable row level security;
alter table public.assignment_settings enable row level security;
alter table public.lead_assignment_history enable row level security;

-- Public roles may not write CRM or assignment data. Admin authorization is enforced server-side
-- and through the existing is_admin() database helper where available.
drop policy if exists "Admins manage lead activity log" on public.lead_activity_log;
create policy "Admins manage lead activity log" on public.lead_activity_log
  for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins manage assignment settings" on public.assignment_settings;
create policy "Admins manage assignment settings" on public.assignment_settings
  for all using (public.is_admin()) with check (public.is_admin());
drop policy if exists "Admins manage lead assignment history" on public.lead_assignment_history;
create policy "Admins manage lead assignment history" on public.lead_assignment_history
  for all using (public.is_admin()) with check (public.is_admin());
