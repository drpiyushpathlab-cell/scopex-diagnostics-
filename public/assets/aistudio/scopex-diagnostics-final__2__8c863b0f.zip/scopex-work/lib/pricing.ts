import type { BookingCatalogItem, FamilyMemberInput, OfferBreakdown } from "@/lib/booking-types";

export type BundleRule = {
  id: string;
  title: string;
  minEligibleTestCount: number;
  /** Optional minimum real-price subtotal for the eligible custom test cart. */
  minEligibleSpend?: number;
  discountType: "percent" | "fixed";
  value: number;
  /** Maximum total saving from this rule, in INR. */
  maxSaving?: number | null;
  /** Fixed packages are excluded unless both this flag and the item flag are enabled. */
  appliesToFixedPackages?: boolean;
  active?: boolean;
  startsAt?: string | null;
  endsAt?: string | null;
};

export type CollectionChargePolicy = {
  enabled: boolean;
  threshold: number;
  charge: number;
  thresholdBasis: "real_price_subtotal" | "after_bundle_saving";
};

export type PricingInput = {
  items: BookingCatalogItem[];
  familyMembers?: FamilyMemberInput[];
  bundleRules?: BundleRule[];
  collectionPolicy?: CollectionChargePolicy;
  /** Optional local date for deterministic previews/tests. Production should pass server time. */
  now?: Date;
};

export type ItemDiscountBreakdown = {
  itemId: string;
  itemName: string;
  basePrice: number;
  requestedDiscount: number;
  capAmount: number | null;
  appliedDiscount: number;
  finalPrice: number;
};

export type PricingQuote = {
  referenceTotal: number;
  realPriceSubtotal: number;
  subtotal: number;
  bundleSaving: number;
  discountTotal: number;
  collectionCharge: number;
  payableAmount: number;
  appliedOffers: OfferBreakdown[];
  freeCollectionThreshold: number;
  itemDiscounts: ItemDiscountBreakdown[];
  savingsAmount: number;
  savingsPercent: number;
};

/**
 * Illustrative default slabs. Admin-managed rules should replace these when the
 * database-backed pricing configuration is connected.
 */
export const defaultBundleRules: BundleRule[] = [
  {
    id: "bundle-2-tests",
    title: "Additional bundle saving",
    minEligibleTestCount: 2,
    discountType: "percent",
    value: 5,
    active: true
  },
  {
    id: "bundle-4-tests",
    title: "Higher bundle saving",
    minEligibleTestCount: 4,
    discountType: "percent",
    value: 10,
    active: true
  }
];

export const defaultCollectionChargePolicy: CollectionChargePolicy = {
  enabled: true,
  threshold: 600,
  charge: 99,
  thresholdBasis: "after_bundle_saving"
};

function money(value: number) {
  return Number.isFinite(value) ? Math.max(0, Math.round(value)) : 0;
}

function quantityFor(item: BookingCatalogItem) {
  const quantity = "quantity" in item ? Number((item as BookingCatalogItem & { quantity?: number }).quantity) : 1;
  return Number.isFinite(quantity) && quantity > 0 ? Math.floor(quantity) : 1;
}

function validRule(rule: BundleRule, now: Date) {
  if (rule.active === false || !Number.isFinite(rule.value) || rule.value < 0) return false;
  if (rule.startsAt && new Date(rule.startsAt).getTime() > now.getTime()) return false;
  if (rule.endsAt && new Date(rule.endsAt).getTime() < now.getTime()) return false;
  return true;
}

function isEligibleForBundle(item: BookingCatalogItem, rule: BundleRule) {
  if (item.kind === "test") {
    const pricedItem = item as BookingCatalogItem & { bundleDiscountEligible?: boolean };
    return pricedItem.bundleDiscountEligible !== false;
  }

  // Fixed packages never receive a test-cart bundle discount by default.
  const packageItem = item as BookingCatalogItem & { bundleDiscountEligible?: boolean; packageType?: "fixed" | "custom" };
  return rule.appliesToFixedPackages === true && packageItem.bundleDiscountEligible === true && packageItem.packageType !== "custom";
}

function capForItem(item: BookingCatalogItem, basePrice: number) {
  const capped = item as BookingCatalogItem & {
    maxDiscountPercent?: number | null;
    maxDiscountAmount?: number | null;
  };
  const percent = capped.maxDiscountPercent;
  const fixed = capped.maxDiscountAmount;
  const hasPercent = percent !== null && percent !== undefined && Number.isFinite(Number(percent)) && Number(percent) >= 0;
  const hasFixed = fixed !== null && fixed !== undefined && Number.isFinite(Number(fixed)) && Number(fixed) >= 0;
  if (!hasPercent && !hasFixed) return null;
  const percentCap = hasPercent ? money((basePrice * Number(percent)) / 100) : Number.POSITIVE_INFINITY;
  const fixedCap = hasFixed ? money(Number(fixed)) : Number.POSITIVE_INFINITY;
  return Math.min(basePrice, percentCap, fixedCap);
}

function selectBundleRule(items: BookingCatalogItem[], rules: BundleRule[], now: Date) {
  const eligibleRules = rules.filter((rule) => {
    if (!validRule(rule, now)) return false;
    const eligibleItems = items.filter((item) => isEligibleForBundle(item, rule));
    const eligibleCount = eligibleItems.reduce((sum, item) => sum + (item.kind === "test" ? quantityFor(item) : 0), 0);
    const eligibleSubtotal = eligibleItems.reduce((sum, item) => sum + money(Number(item.price) * quantityFor(item)), 0);
    if (eligibleCount < rule.minEligibleTestCount) return false;
    if (rule.minEligibleSpend !== undefined && eligibleSubtotal < rule.minEligibleSpend) return false;
    return true;
  });

  return eligibleRules.sort((a, b) => {
    if (a.minEligibleTestCount !== b.minEligibleTestCount) return b.minEligibleTestCount - a.minEligibleTestCount;
    if ((a.minEligibleSpend ?? 0) !== (b.minEligibleSpend ?? 0)) return (b.minEligibleSpend ?? 0) - (a.minEligibleSpend ?? 0);
    return b.value - a.value;
  })[0];
}

function distributeTotalCap(rows: ItemDiscountBreakdown[], totalCap: number | null | undefined) {
  const currentTotal = rows.reduce((sum, row) => sum + row.appliedDiscount, 0);
  if (totalCap === null || totalCap === undefined || !Number.isFinite(totalCap) || currentTotal <= totalCap) return rows;
  const allowed = Math.min(currentTotal, money(totalCap));
  if (allowed === 0 || currentTotal === 0) return rows.map((row) => ({ ...row, appliedDiscount: 0, finalPrice: row.basePrice }));

  const rawAllocations = rows.map((row) => (row.appliedDiscount / currentTotal) * allowed);
  const allocations = rawAllocations.map((raw, index) => Math.min(rows[index].appliedDiscount, Math.floor(raw)));
  let remaining = allowed - allocations.reduce((sum, value) => sum + value, 0);
  const order = rows.map((row, index) => ({ index, remainder: rawAllocations[index] - Math.floor(rawAllocations[index]) }))
    .sort((a, b) => b.remainder - a.remainder);
  for (const entry of order) {
    if (remaining <= 0) break;
    if (allocations[entry.index] < rows[entry.index].appliedDiscount) {
      allocations[entry.index] += 1;
      remaining -= 1;
    }
  }
  return rows.map((row, index) => ({
    ...row,
    appliedDiscount: allocations[index],
    finalPrice: money(row.basePrice - allocations[index])
  }));
}

export function calculateRealPriceQuote({
  items,
  bundleRules = defaultBundleRules,
  collectionPolicy = defaultCollectionChargePolicy,
  now = new Date()
}: PricingInput): PricingQuote {
  const normalizedItems = items.map((item) => ({
    item,
    quantity: quantityFor(item),
    price: money(Number(item.price || 0)),
    referencePrice: Math.max(money(Number(item.mrp || 0)), money(Number(item.price || 0)))
  }));

  const realPriceSubtotal = normalizedItems.reduce((sum, row) => sum + row.price * row.quantity, 0);
  const referenceTotal = normalizedItems.reduce((sum, row) => sum + row.referencePrice * row.quantity, 0);
  const bundleRule = selectBundleRule(items, bundleRules, now);
  const eligibleRows = bundleRule ? normalizedItems.filter(({ item }) => isEligibleForBundle(item, bundleRule)) : [];
  const eligibleSubtotal = eligibleRows.reduce((sum, row) => sum + row.price * row.quantity, 0);
  const requestedTotal = bundleRule
    ? bundleRule.discountType === "percent"
      ? money((eligibleSubtotal * bundleRule.value) / 100)
      : Math.min(eligibleSubtotal, money(bundleRule.value))
    : 0;

  let itemDiscounts: ItemDiscountBreakdown[] = [];
  if (bundleRule && requestedTotal > 0 && eligibleSubtotal > 0) {
    itemDiscounts = eligibleRows.map(({ item, price, quantity }) => {
      const lineBasePrice = price * quantity;
      const requestedDiscount = bundleRule.discountType === "percent"
        ? money((lineBasePrice * bundleRule.value) / 100)
        : money((requestedTotal * lineBasePrice) / eligibleSubtotal);
      const perUnitCap = capForItem(item, price);
      const lineCap = perUnitCap === null ? null : perUnitCap * quantity;
      const appliedDiscount = Math.min(lineBasePrice, requestedDiscount, lineCap ?? Number.POSITIVE_INFINITY);
      return {
        itemId: item.id,
        itemName: item.name,
        basePrice: lineBasePrice,
        requestedDiscount,
        capAmount: lineCap,
        appliedDiscount: money(appliedDiscount),
        finalPrice: money(lineBasePrice - appliedDiscount)
      };
    });
    const totalDiscountCap = bundleRule.maxSaving == null
      ? requestedTotal
      : Math.min(requestedTotal, money(bundleRule.maxSaving));
    itemDiscounts = distributeTotalCap(itemDiscounts, totalDiscountCap);
  }

  const bundleSaving = money(itemDiscounts.reduce((sum, row) => sum + row.appliedDiscount, 0));
  const basisTotal = collectionPolicy.thresholdBasis === "real_price_subtotal" ? realPriceSubtotal : realPriceSubtotal - bundleSaving;
  const collectionCharge = collectionPolicy.enabled && realPriceSubtotal > 0 && basisTotal < collectionPolicy.threshold
    ? money(collectionPolicy.charge)
    : 0;
  const payableAmount = money(realPriceSubtotal - bundleSaving + collectionCharge);
  const appliedOffers: OfferBreakdown[] = bundleRule && bundleSaving > 0
    ? [{
        code: bundleRule.id.toUpperCase(),
        title: bundleRule.title,
        discountAmount: bundleSaving,
        description: `Applied automatically for ${bundleRule.minEligibleTestCount}+ eligible tests; per-test caps enforced`
      }]
    : [];
  const savingsAmount = money(Math.max(0, referenceTotal - (realPriceSubtotal - bundleSaving)));
  const savingsPercent = referenceTotal > 0 ? Math.round((savingsAmount / referenceTotal) * 10000) / 100 : 0;

  return {
    referenceTotal,
    realPriceSubtotal,
    subtotal: realPriceSubtotal,
    bundleSaving,
    discountTotal: bundleSaving,
    collectionCharge,
    payableAmount,
    appliedOffers,
    freeCollectionThreshold: collectionPolicy.threshold,
    itemDiscounts,
    savingsAmount,
    savingsPercent
  };
}
