import { getSupabaseServiceClient } from "@/lib/supabase";
import type { LeadPayload } from "@/lib/validation";

function startOfTodayIso() {
  const today = new Date();
  today.setHours(0, 0, 0, 0);
  return today.toISOString();
}

function leadEmail(payload: LeadPayload) {
  return payload.officialEmail || null;
}

export async function storeLeadInSupabase(payload: LeadPayload) {
  const supabase = getSupabaseServiceClient();
  const phone = payload.mobileNumber;
  const email = leadEmail(payload);
  const duplicateFilters = [`phone.eq.${phone}`, `mobile.eq.${phone}`, `mobile_number.eq.${phone}`];
  if (email) duplicateFilters.push(`email.eq.${email}`, `official_email.eq.${email}`);

  const { data: existing, error: lookupError } = await supabase
    .from("leads")
    .select("id, created_at")
    .eq("lead_type", payload.leadType)
    .gte("created_at", startOfTodayIso())
    .or(duplicateFilters.join(","))
    .limit(1);

  if (lookupError) throw new Error(lookupError.message || "Unable to check duplicate lead.");
  if ((existing ?? []).length > 0) return { duplicate: true };

  // Default safely to manual assignment. Automatic routing is only enabled when
  // an explicit database setting exists and eligible staff are available.
  let assignmentMode: "manual" | "automatic" = "manual";
  let assignedUserId: string | null = null;
  let assignedTeam: string | null = null;
  const { data: setting } = await supabase
    .from("assignment_settings")
    .select("assignment_mode, active")
    .eq("workflow", "crm_leads")
    .maybeSingle();

  if (setting?.active && setting.assignment_mode === "automatic") {
    const { data: staff } = await supabase
      .from("admin_roles")
      .select("user_id, role")
      .in("role", ["customer_support", "booking_manager"]);

    const staffIds = (staff ?? []).map((row) => String(row.user_id || "")).filter(Boolean);
    if (staffIds.length) {
      const { data: openLeads } = await supabase.from("leads").select("assigned_user_id, lead_status").in("assigned_user_id", staffIds);
      const terminalStatuses = new Set(["Converted", "Closed", "Not Interested"]);
      const loads = new Map(staffIds.map((id) => [id, 0]));
      for (const row of openLeads ?? []) {
        const owner = String(row.assigned_user_id || "");
        const status = String(row.lead_status || "New");
        if (loads.has(owner) && !terminalStatuses.has(status)) loads.set(owner, (loads.get(owner) || 0) + 1);
      }
      assignedUserId = staffIds.sort((a, b) => (loads.get(a) || 0) - (loads.get(b) || 0))[0] || null;
      if (assignedUserId) {
        assignmentMode = "automatic";
        assignedTeam = "customer_support";
      }
    }
  }

  const { data: insertedLead, error } = await supabase.from("leads").insert({
    lead_type: payload.leadType,
    name: payload.name,
    age: payload.age ?? null,
    gender: payload.gender ?? null,
    phone,
    mobile: phone,
    mobile_number: phone,
    email,
    official_email: payload.officialEmail || null,
    city: payload.city || null,
    state: payload.state || null,
    address: payload.address || null,
    preferred_time: payload.preferredTime || null,
    purpose: payload.purpose || null,
    company_name: payload.companyName || null,
    contact_person: payload.contactPerson || null,
    designation: payload.designation || null,
    company_website: payload.companyWebsite || null,
    business_type: payload.businessType || null,
    expected_monthly_volume: payload.expectedMonthlyVolume || null,
    collection_date: payload.collectionDate || null,
    appointment_date: payload.appointmentDate || null,
    family_members: payload.familyMembers || null,
    message: payload.message || null,
    consent: payload.consent === true,
    status: "new",
    lead_status: "New",
    priority: "normal",
    source: "website",
    campaign: null,
    metadata: payload,
    assigned_user_id: assignedUserId,
    assigned_team: assignedTeam
  }).select("id").single();

  if (error) throw new Error(error.message || "Unable to save lead.");
  if (insertedLead?.id && assignedUserId) {
    // Assignment history is useful for auditing but must not roll back lead capture
    // if a partially migrated environment does not yet have the history table.
    await supabase.from("lead_assignment_history").insert({
      lead_id: insertedLead.id,
      from_user_id: null,
      to_user_id: assignedUserId,
      team: assignedTeam,
      assignment_mode: assignmentMode,
      rule_snapshot: { strategy: "least_open_leads", workflow: "crm_leads" }
    });
  }
  return { duplicate: false, assigned: Boolean(assignedUserId), assignmentMode };
}
